﻿namespace exam_program
{
    partial class Form8
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form8));
            first1_1 = new System.Windows.Forms.RadioButton();
            sec2_1 = new System.Windows.Forms.RadioButton();
            th3_1 = new System.Windows.Forms.RadioButton();
            four4_1 = new System.Windows.Forms.RadioButton();
            textBox1 = new System.Windows.Forms.TextBox();
            button2 = new System.Windows.Forms.Button();
            textBox2 = new System.Windows.Forms.TextBox();
            first1_2 = new System.Windows.Forms.RadioButton();
            sec2_2 = new System.Windows.Forms.RadioButton();
            th3_2 = new System.Windows.Forms.RadioButton();
            four4_2 = new System.Windows.Forms.RadioButton();
            textBox3 = new System.Windows.Forms.TextBox();
            first1_3 = new System.Windows.Forms.RadioButton();
            sec2_3 = new System.Windows.Forms.RadioButton();
            th3_3 = new System.Windows.Forms.RadioButton();
            four4_3 = new System.Windows.Forms.RadioButton();
            textBox4 = new System.Windows.Forms.TextBox();
            first1_5 = new System.Windows.Forms.RadioButton();
            sec2_5 = new System.Windows.Forms.RadioButton();
            th3_5 = new System.Windows.Forms.RadioButton();
            four4_5 = new System.Windows.Forms.RadioButton();
            textBox5 = new System.Windows.Forms.TextBox();
            first1_4 = new System.Windows.Forms.RadioButton();
            sec2_4 = new System.Windows.Forms.RadioButton();
            th3_4 = new System.Windows.Forms.RadioButton();
            four4_4 = new System.Windows.Forms.RadioButton();
            button4 = new System.Windows.Forms.Button();
            groupBox1 = new System.Windows.Forms.GroupBox();
            label4 = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            label1 = new System.Windows.Forms.Label();
            groupBox2 = new System.Windows.Forms.GroupBox();
            label8 = new System.Windows.Forms.Label();
            label7 = new System.Windows.Forms.Label();
            label6 = new System.Windows.Forms.Label();
            label5 = new System.Windows.Forms.Label();
            groupBox3 = new System.Windows.Forms.GroupBox();
            label12 = new System.Windows.Forms.Label();
            label11 = new System.Windows.Forms.Label();
            label10 = new System.Windows.Forms.Label();
            label9 = new System.Windows.Forms.Label();
            groupBox4 = new System.Windows.Forms.GroupBox();
            label16 = new System.Windows.Forms.Label();
            label15 = new System.Windows.Forms.Label();
            label14 = new System.Windows.Forms.Label();
            label13 = new System.Windows.Forms.Label();
            groupBox5 = new System.Windows.Forms.GroupBox();
            label20 = new System.Windows.Forms.Label();
            label19 = new System.Windows.Forms.Label();
            label18 = new System.Windows.Forms.Label();
            label17 = new System.Windows.Forms.Label();
            pictureBox1 = new System.Windows.Forms.PictureBox();
            groupBox6 = new System.Windows.Forms.GroupBox();
            groupBox7 = new System.Windows.Forms.GroupBox();
            groupBox12 = new System.Windows.Forms.GroupBox();
            groupBox11 = new System.Windows.Forms.GroupBox();
            groupBox10 = new System.Windows.Forms.GroupBox();
            groupBox9 = new System.Windows.Forms.GroupBox();
            groupBox8 = new System.Windows.Forms.GroupBox();
            label21 = new System.Windows.Forms.Label();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            groupBox3.SuspendLayout();
            groupBox4.SuspendLayout();
            groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            groupBox7.SuspendLayout();
            groupBox12.SuspendLayout();
            groupBox11.SuspendLayout();
            groupBox10.SuspendLayout();
            groupBox9.SuspendLayout();
            groupBox8.SuspendLayout();
            SuspendLayout();
            // 
            // first1_1
            // 
            first1_1.AutoSize = true;
            first1_1.Location = new System.Drawing.Point(38, 22);
            first1_1.Name = "first1_1";
            first1_1.Size = new System.Drawing.Size(95, 19);
            first1_1.TabIndex = 0;
            first1_1.TabStop = true;
            first1_1.Text = "radioButton1";
            first1_1.UseVisualStyleBackColor = true;
            // 
            // sec2_1
            // 
            sec2_1.AutoSize = true;
            sec2_1.Location = new System.Drawing.Point(206, 22);
            sec2_1.Name = "sec2_1";
            sec2_1.Size = new System.Drawing.Size(95, 19);
            sec2_1.TabIndex = 1;
            sec2_1.TabStop = true;
            sec2_1.Text = "radioButton2";
            sec2_1.UseVisualStyleBackColor = true;
            // 
            // th3_1
            // 
            th3_1.AutoSize = true;
            th3_1.Location = new System.Drawing.Point(395, 22);
            th3_1.Name = "th3_1";
            th3_1.Size = new System.Drawing.Size(95, 19);
            th3_1.TabIndex = 2;
            th3_1.TabStop = true;
            th3_1.Text = "radioButton3";
            th3_1.UseVisualStyleBackColor = true;
            // 
            // four4_1
            // 
            four4_1.AutoSize = true;
            four4_1.Location = new System.Drawing.Point(581, 22);
            four4_1.Name = "four4_1";
            four4_1.Size = new System.Drawing.Size(95, 19);
            four4_1.TabIndex = 3;
            four4_1.TabStop = true;
            four4_1.Text = "radioButton4";
            four4_1.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            textBox1.Location = new System.Drawing.Point(11, 22);
            textBox1.Name = "textBox1";
            textBox1.Size = new System.Drawing.Size(677, 23);
            textBox1.TabIndex = 4;
            // 
            // button2
            // 
            button2.Location = new System.Drawing.Point(896, 686);
            button2.Name = "button2";
            button2.Size = new System.Drawing.Size(93, 57);
            button2.TabIndex = 7;
            button2.Text = "값 읽어오기";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // textBox2
            // 
            textBox2.Location = new System.Drawing.Point(16, 22);
            textBox2.Name = "textBox2";
            textBox2.Size = new System.Drawing.Size(677, 23);
            textBox2.TabIndex = 4;
            // 
            // first1_2
            // 
            first1_2.AutoSize = true;
            first1_2.Location = new System.Drawing.Point(33, 21);
            first1_2.Name = "first1_2";
            first1_2.Size = new System.Drawing.Size(95, 19);
            first1_2.TabIndex = 9;
            first1_2.TabStop = true;
            first1_2.Text = "radioButton5";
            first1_2.UseVisualStyleBackColor = true;
            // 
            // sec2_2
            // 
            sec2_2.AutoSize = true;
            sec2_2.Location = new System.Drawing.Point(201, 21);
            sec2_2.Name = "sec2_2";
            sec2_2.Size = new System.Drawing.Size(95, 19);
            sec2_2.TabIndex = 9;
            sec2_2.TabStop = true;
            sec2_2.Text = "radioButton5";
            sec2_2.UseVisualStyleBackColor = true;
            // 
            // th3_2
            // 
            th3_2.AutoSize = true;
            th3_2.Location = new System.Drawing.Point(390, 21);
            th3_2.Name = "th3_2";
            th3_2.Size = new System.Drawing.Size(95, 19);
            th3_2.TabIndex = 9;
            th3_2.TabStop = true;
            th3_2.Text = "radioButton5";
            th3_2.UseVisualStyleBackColor = true;
            // 
            // four4_2
            // 
            four4_2.AutoSize = true;
            four4_2.Location = new System.Drawing.Point(576, 21);
            four4_2.Name = "four4_2";
            four4_2.Size = new System.Drawing.Size(95, 19);
            four4_2.TabIndex = 9;
            four4_2.TabStop = true;
            four4_2.Text = "radioButton5";
            four4_2.UseVisualStyleBackColor = true;
            // 
            // textBox3
            // 
            textBox3.Location = new System.Drawing.Point(16, 28);
            textBox3.Name = "textBox3";
            textBox3.Size = new System.Drawing.Size(677, 23);
            textBox3.TabIndex = 4;
            // 
            // first1_3
            // 
            first1_3.AutoSize = true;
            first1_3.Location = new System.Drawing.Point(30, 22);
            first1_3.Name = "first1_3";
            first1_3.Size = new System.Drawing.Size(95, 19);
            first1_3.TabIndex = 9;
            first1_3.TabStop = true;
            first1_3.Text = "radioButton5";
            first1_3.UseVisualStyleBackColor = true;
            // 
            // sec2_3
            // 
            sec2_3.AutoSize = true;
            sec2_3.Location = new System.Drawing.Point(198, 22);
            sec2_3.Name = "sec2_3";
            sec2_3.Size = new System.Drawing.Size(95, 19);
            sec2_3.TabIndex = 9;
            sec2_3.TabStop = true;
            sec2_3.Text = "radioButton5";
            sec2_3.UseVisualStyleBackColor = true;
            // 
            // th3_3
            // 
            th3_3.AutoSize = true;
            th3_3.Location = new System.Drawing.Point(387, 22);
            th3_3.Name = "th3_3";
            th3_3.Size = new System.Drawing.Size(95, 19);
            th3_3.TabIndex = 9;
            th3_3.TabStop = true;
            th3_3.Text = "radioButton5";
            th3_3.UseVisualStyleBackColor = true;
            // 
            // four4_3
            // 
            four4_3.AutoSize = true;
            four4_3.Location = new System.Drawing.Point(573, 22);
            four4_3.Name = "four4_3";
            four4_3.Size = new System.Drawing.Size(95, 19);
            four4_3.TabIndex = 9;
            four4_3.TabStop = true;
            four4_3.Text = "radioButton5";
            four4_3.UseVisualStyleBackColor = true;
            // 
            // textBox4
            // 
            textBox4.Location = new System.Drawing.Point(16, 22);
            textBox4.Name = "textBox4";
            textBox4.Size = new System.Drawing.Size(677, 23);
            textBox4.TabIndex = 4;
            // 
            // first1_5
            // 
            first1_5.AutoSize = true;
            first1_5.Location = new System.Drawing.Point(23, 16);
            first1_5.Name = "first1_5";
            first1_5.Size = new System.Drawing.Size(95, 19);
            first1_5.TabIndex = 9;
            first1_5.TabStop = true;
            first1_5.Text = "radioButton5";
            first1_5.UseVisualStyleBackColor = true;
            // 
            // sec2_5
            // 
            sec2_5.AutoSize = true;
            sec2_5.Location = new System.Drawing.Point(191, 16);
            sec2_5.Name = "sec2_5";
            sec2_5.Size = new System.Drawing.Size(95, 19);
            sec2_5.TabIndex = 9;
            sec2_5.TabStop = true;
            sec2_5.Text = "radioButton5";
            sec2_5.UseVisualStyleBackColor = true;
            // 
            // th3_5
            // 
            th3_5.AutoSize = true;
            th3_5.Location = new System.Drawing.Point(380, 16);
            th3_5.Name = "th3_5";
            th3_5.Size = new System.Drawing.Size(95, 19);
            th3_5.TabIndex = 9;
            th3_5.TabStop = true;
            th3_5.Text = "radioButton5";
            th3_5.UseVisualStyleBackColor = true;
            // 
            // four4_5
            // 
            four4_5.AutoSize = true;
            four4_5.Location = new System.Drawing.Point(572, 16);
            four4_5.Name = "four4_5";
            four4_5.Size = new System.Drawing.Size(95, 19);
            four4_5.TabIndex = 9;
            four4_5.TabStop = true;
            four4_5.Text = "radioButton5";
            four4_5.UseVisualStyleBackColor = true;
            // 
            // textBox5
            // 
            textBox5.Location = new System.Drawing.Point(16, 24);
            textBox5.Name = "textBox5";
            textBox5.Size = new System.Drawing.Size(677, 23);
            textBox5.TabIndex = 4;
            // 
            // first1_4
            // 
            first1_4.AutoSize = true;
            first1_4.Location = new System.Drawing.Point(30, 10);
            first1_4.Name = "first1_4";
            first1_4.Size = new System.Drawing.Size(95, 19);
            first1_4.TabIndex = 9;
            first1_4.TabStop = true;
            first1_4.Text = "radioButton5";
            first1_4.UseVisualStyleBackColor = true;
            // 
            // sec2_4
            // 
            sec2_4.AutoSize = true;
            sec2_4.Location = new System.Drawing.Point(198, 10);
            sec2_4.Name = "sec2_4";
            sec2_4.Size = new System.Drawing.Size(95, 19);
            sec2_4.TabIndex = 9;
            sec2_4.TabStop = true;
            sec2_4.Text = "radioButton5";
            sec2_4.UseVisualStyleBackColor = true;
            // 
            // th3_4
            // 
            th3_4.AutoSize = true;
            th3_4.Location = new System.Drawing.Point(387, 10);
            th3_4.Name = "th3_4";
            th3_4.Size = new System.Drawing.Size(95, 19);
            th3_4.TabIndex = 9;
            th3_4.TabStop = true;
            th3_4.Text = "radioButton5";
            th3_4.UseVisualStyleBackColor = true;
            // 
            // four4_4
            // 
            four4_4.AutoSize = true;
            four4_4.Location = new System.Drawing.Point(579, 10);
            four4_4.Name = "four4_4";
            four4_4.Size = new System.Drawing.Size(95, 19);
            four4_4.TabIndex = 9;
            four4_4.TabStop = true;
            four4_4.Text = "radioButton5";
            four4_4.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            button4.Location = new System.Drawing.Point(1038, 686);
            button4.Name = "button4";
            button4.Size = new System.Drawing.Size(97, 57);
            button4.TabIndex = 8;
            button4.Text = "문제 제출";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Controls.Add(first1_1);
            groupBox1.Controls.Add(sec2_1);
            groupBox1.Controls.Add(th3_1);
            groupBox1.Controls.Add(four4_1);
            groupBox1.Location = new System.Drawing.Point(6, 50);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new System.Drawing.Size(761, 54);
            groupBox1.TabIndex = 12;
            groupBox1.TabStop = false;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new System.Drawing.Point(561, 24);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(14, 15);
            label4.TabIndex = 4;
            label4.Text = "4";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new System.Drawing.Point(375, 24);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(14, 15);
            label3.TabIndex = 4;
            label3.Text = "3";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new System.Drawing.Point(186, 24);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(14, 15);
            label2.TabIndex = 4;
            label2.Text = "2";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new System.Drawing.Point(18, 26);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(14, 15);
            label1.TabIndex = 4;
            label1.Text = "1";
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(label8);
            groupBox2.Controls.Add(label7);
            groupBox2.Controls.Add(first1_2);
            groupBox2.Controls.Add(label6);
            groupBox2.Controls.Add(sec2_2);
            groupBox2.Controls.Add(label5);
            groupBox2.Controls.Add(th3_2);
            groupBox2.Controls.Add(four4_2);
            groupBox2.Location = new System.Drawing.Point(8, 58);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new System.Drawing.Size(756, 46);
            groupBox2.TabIndex = 13;
            groupBox2.TabStop = false;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new System.Drawing.Point(556, 23);
            label8.Name = "label8";
            label8.Size = new System.Drawing.Size(14, 15);
            label8.TabIndex = 4;
            label8.Text = "4";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new System.Drawing.Point(370, 23);
            label7.Name = "label7";
            label7.Size = new System.Drawing.Size(14, 15);
            label7.TabIndex = 4;
            label7.Text = "3";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new System.Drawing.Point(181, 23);
            label6.Name = "label6";
            label6.Size = new System.Drawing.Size(14, 15);
            label6.TabIndex = 4;
            label6.Text = "2";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new System.Drawing.Point(13, 23);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(14, 15);
            label5.TabIndex = 4;
            label5.Text = "1";
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(label12);
            groupBox3.Controls.Add(first1_3);
            groupBox3.Controls.Add(label11);
            groupBox3.Controls.Add(sec2_3);
            groupBox3.Controls.Add(th3_3);
            groupBox3.Controls.Add(label10);
            groupBox3.Controls.Add(four4_3);
            groupBox3.Controls.Add(label9);
            groupBox3.Location = new System.Drawing.Point(11, 57);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new System.Drawing.Size(753, 47);
            groupBox3.TabIndex = 14;
            groupBox3.TabStop = false;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new System.Drawing.Point(553, 24);
            label12.Name = "label12";
            label12.Size = new System.Drawing.Size(14, 15);
            label12.TabIndex = 4;
            label12.Text = "4";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new System.Drawing.Point(367, 24);
            label11.Name = "label11";
            label11.Size = new System.Drawing.Size(14, 15);
            label11.TabIndex = 4;
            label11.Text = "3";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new System.Drawing.Point(178, 24);
            label10.Name = "label10";
            label10.Size = new System.Drawing.Size(14, 15);
            label10.TabIndex = 4;
            label10.Text = "2";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new System.Drawing.Point(10, 24);
            label9.Name = "label9";
            label9.Size = new System.Drawing.Size(14, 15);
            label9.TabIndex = 4;
            label9.Text = "1";
            // 
            // groupBox4
            // 
            groupBox4.Controls.Add(label16);
            groupBox4.Controls.Add(label15);
            groupBox4.Controls.Add(four4_4);
            groupBox4.Controls.Add(th3_4);
            groupBox4.Controls.Add(label14);
            groupBox4.Controls.Add(sec2_4);
            groupBox4.Controls.Add(first1_4);
            groupBox4.Controls.Add(label13);
            groupBox4.Location = new System.Drawing.Point(11, 58);
            groupBox4.Name = "groupBox4";
            groupBox4.Size = new System.Drawing.Size(753, 46);
            groupBox4.TabIndex = 15;
            groupBox4.TabStop = false;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Location = new System.Drawing.Point(559, 12);
            label16.Name = "label16";
            label16.Size = new System.Drawing.Size(14, 15);
            label16.TabIndex = 4;
            label16.Text = "4";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new System.Drawing.Point(367, 12);
            label15.Name = "label15";
            label15.Size = new System.Drawing.Size(14, 15);
            label15.TabIndex = 4;
            label15.Text = "3";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new System.Drawing.Point(178, 12);
            label14.Name = "label14";
            label14.Size = new System.Drawing.Size(14, 15);
            label14.TabIndex = 4;
            label14.Text = "2";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new System.Drawing.Point(10, 12);
            label13.Name = "label13";
            label13.Size = new System.Drawing.Size(14, 15);
            label13.TabIndex = 4;
            label13.Text = "1";
            // 
            // groupBox5
            // 
            groupBox5.Controls.Add(label20);
            groupBox5.Controls.Add(first1_5);
            groupBox5.Controls.Add(label19);
            groupBox5.Controls.Add(sec2_5);
            groupBox5.Controls.Add(th3_5);
            groupBox5.Controls.Add(four4_5);
            groupBox5.Controls.Add(label18);
            groupBox5.Controls.Add(label17);
            groupBox5.Location = new System.Drawing.Point(18, 53);
            groupBox5.Name = "groupBox5";
            groupBox5.Size = new System.Drawing.Size(746, 41);
            groupBox5.TabIndex = 16;
            groupBox5.TabStop = false;
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Location = new System.Drawing.Point(552, 18);
            label20.Name = "label20";
            label20.Size = new System.Drawing.Size(14, 15);
            label20.TabIndex = 4;
            label20.Text = "4";
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Location = new System.Drawing.Point(360, 16);
            label19.Name = "label19";
            label19.Size = new System.Drawing.Size(14, 15);
            label19.TabIndex = 4;
            label19.Text = "3";
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Location = new System.Drawing.Point(171, 16);
            label18.Name = "label18";
            label18.Size = new System.Drawing.Size(14, 15);
            label18.TabIndex = 4;
            label18.Text = "2";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Location = new System.Drawing.Point(3, 16);
            label17.Name = "label17";
            label17.Size = new System.Drawing.Size(14, 15);
            label17.TabIndex = 4;
            label17.Text = "1";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (System.Drawing.Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new System.Drawing.Point(1, -1);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new System.Drawing.Size(286, 50);
            pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 17;
            pictureBox1.TabStop = false;
            // 
            // groupBox6
            // 
            groupBox6.BackColor = System.Drawing.Color.Black;
            groupBox6.Location = new System.Drawing.Point(1, 46);
            groupBox6.Name = "groupBox6";
            groupBox6.Size = new System.Drawing.Size(1200, 3);
            groupBox6.TabIndex = 18;
            groupBox6.TabStop = false;
            groupBox6.Text = "groupBox6";
            // 
            // groupBox7
            // 
            groupBox7.BackColor = System.Drawing.Color.DimGray;
            groupBox7.Controls.Add(groupBox12);
            groupBox7.Controls.Add(groupBox11);
            groupBox7.Controls.Add(groupBox10);
            groupBox7.Controls.Add(groupBox9);
            groupBox7.Controls.Add(groupBox8);
            groupBox7.Location = new System.Drawing.Point(18, 81);
            groupBox7.Name = "groupBox7";
            groupBox7.Size = new System.Drawing.Size(831, 668);
            groupBox7.TabIndex = 19;
            groupBox7.TabStop = false;
            // 
            // groupBox12
            // 
            groupBox12.BackColor = System.Drawing.Color.LightGray;
            groupBox12.Controls.Add(groupBox5);
            groupBox12.Controls.Add(textBox5);
            groupBox12.Location = new System.Drawing.Point(12, 552);
            groupBox12.Name = "groupBox12";
            groupBox12.Size = new System.Drawing.Size(800, 110);
            groupBox12.TabIndex = 4;
            groupBox12.TabStop = false;
            groupBox12.Text = "문제 5번";
            // 
            // groupBox11
            // 
            groupBox11.BackColor = System.Drawing.Color.LightGray;
            groupBox11.Controls.Add(groupBox4);
            groupBox11.Controls.Add(textBox4);
            groupBox11.Location = new System.Drawing.Point(12, 420);
            groupBox11.Name = "groupBox11";
            groupBox11.Size = new System.Drawing.Size(800, 110);
            groupBox11.TabIndex = 3;
            groupBox11.TabStop = false;
            groupBox11.Text = "문제 4번";
            // 
            // groupBox10
            // 
            groupBox10.BackColor = System.Drawing.Color.LightGray;
            groupBox10.Controls.Add(textBox3);
            groupBox10.Controls.Add(groupBox3);
            groupBox10.Location = new System.Drawing.Point(12, 293);
            groupBox10.Name = "groupBox10";
            groupBox10.Size = new System.Drawing.Size(800, 110);
            groupBox10.TabIndex = 2;
            groupBox10.TabStop = false;
            groupBox10.Text = "문제 3번";
            // 
            // groupBox9
            // 
            groupBox9.BackColor = System.Drawing.Color.LightGray;
            groupBox9.Controls.Add(textBox2);
            groupBox9.Controls.Add(groupBox2);
            groupBox9.Location = new System.Drawing.Point(12, 163);
            groupBox9.Name = "groupBox9";
            groupBox9.Size = new System.Drawing.Size(800, 110);
            groupBox9.TabIndex = 1;
            groupBox9.TabStop = false;
            groupBox9.Text = "문제 2번";
            // 
            // groupBox8
            // 
            groupBox8.BackColor = System.Drawing.Color.LightGray;
            groupBox8.Controls.Add(groupBox1);
            groupBox8.Controls.Add(textBox1);
            groupBox8.Location = new System.Drawing.Point(9, 32);
            groupBox8.Name = "groupBox8";
            groupBox8.Size = new System.Drawing.Size(800, 110);
            groupBox8.TabIndex = 0;
            groupBox8.TabStop = false;
            groupBox8.Text = "문제 1번";
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Font = new System.Drawing.Font("휴먼둥근헤드라인", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            label21.Location = new System.Drawing.Point(976, 24);
            label21.Name = "label21";
            label21.Size = new System.Drawing.Size(196, 19);
            label21.TabIndex = 30;
            label21.Text = "출제자님 환영합니다.";
            // 
            // Form8
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            BackColor = System.Drawing.Color.White;
            ClientSize = new System.Drawing.Size(1184, 761);
            Controls.Add(label21);
            Controls.Add(groupBox6);
            Controls.Add(pictureBox1);
            Controls.Add(button4);
            Controls.Add(button2);
            Controls.Add(groupBox7);
            Name = "Form8";
            Text = "시험";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            groupBox4.ResumeLayout(false);
            groupBox4.PerformLayout();
            groupBox5.ResumeLayout(false);
            groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            groupBox7.ResumeLayout(false);
            groupBox12.ResumeLayout(false);
            groupBox12.PerformLayout();
            groupBox11.ResumeLayout(false);
            groupBox11.PerformLayout();
            groupBox10.ResumeLayout(false);
            groupBox10.PerformLayout();
            groupBox9.ResumeLayout(false);
            groupBox9.PerformLayout();
            groupBox8.ResumeLayout(false);
            groupBox8.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.RadioButton first1_1;
        private System.Windows.Forms.RadioButton sec2_1;
        private System.Windows.Forms.RadioButton th3_1;
        private System.Windows.Forms.RadioButton four4_1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.RadioButton first1_2;
        private System.Windows.Forms.RadioButton sec2_2;
        private System.Windows.Forms.RadioButton th3_2;
        private System.Windows.Forms.RadioButton four4_2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.RadioButton first1_3;
        private System.Windows.Forms.RadioButton sec2_3;
        private System.Windows.Forms.RadioButton th3_3;
        private System.Windows.Forms.RadioButton four4_3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.RadioButton first1_5;
        private System.Windows.Forms.RadioButton sec2_5;
        private System.Windows.Forms.RadioButton th3_5;
        private System.Windows.Forms.RadioButton four4_5;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.RadioButton first1_4;
        private System.Windows.Forms.RadioButton sec2_4;
        private System.Windows.Forms.RadioButton th3_4;
        private System.Windows.Forms.RadioButton four4_4;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label21;
    }
}