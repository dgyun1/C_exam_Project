﻿namespace exam_program
{
    partial class Form6
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form6));
            exam_num1 = new System.Windows.Forms.TextBox();
            label1 = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            groupBox1 = new System.Windows.Forms.GroupBox();
            label3 = new System.Windows.Forms.Label();
            comboBox1 = new System.Windows.Forms.ComboBox();
            label7 = new System.Windows.Forms.Label();
            num1_3 = new System.Windows.Forms.TextBox();
            label5 = new System.Windows.Forms.Label();
            num1_4 = new System.Windows.Forms.TextBox();
            label4 = new System.Windows.Forms.Label();
            num1_2 = new System.Windows.Forms.TextBox();
            num1_1 = new System.Windows.Forms.TextBox();
            button1 = new System.Windows.Forms.Button();
            groupBox2 = new System.Windows.Forms.GroupBox();
            label6 = new System.Windows.Forms.Label();
            comboBox2 = new System.Windows.Forms.ComboBox();
            label8 = new System.Windows.Forms.Label();
            label9 = new System.Windows.Forms.Label();
            exam_num2 = new System.Windows.Forms.TextBox();
            num2_3 = new System.Windows.Forms.TextBox();
            label10 = new System.Windows.Forms.Label();
            label11 = new System.Windows.Forms.Label();
            num2_4 = new System.Windows.Forms.TextBox();
            label12 = new System.Windows.Forms.Label();
            num2_2 = new System.Windows.Forms.TextBox();
            num2_1 = new System.Windows.Forms.TextBox();
            groupBox3 = new System.Windows.Forms.GroupBox();
            label13 = new System.Windows.Forms.Label();
            comboBox3 = new System.Windows.Forms.ComboBox();
            label14 = new System.Windows.Forms.Label();
            label15 = new System.Windows.Forms.Label();
            exam_num3 = new System.Windows.Forms.TextBox();
            num3_3 = new System.Windows.Forms.TextBox();
            label16 = new System.Windows.Forms.Label();
            label17 = new System.Windows.Forms.Label();
            num3_4 = new System.Windows.Forms.TextBox();
            label18 = new System.Windows.Forms.Label();
            num3_2 = new System.Windows.Forms.TextBox();
            num3_1 = new System.Windows.Forms.TextBox();
            groupBox4 = new System.Windows.Forms.GroupBox();
            label19 = new System.Windows.Forms.Label();
            comboBox4 = new System.Windows.Forms.ComboBox();
            label20 = new System.Windows.Forms.Label();
            label21 = new System.Windows.Forms.Label();
            exam_num4 = new System.Windows.Forms.TextBox();
            num4_3 = new System.Windows.Forms.TextBox();
            label22 = new System.Windows.Forms.Label();
            label23 = new System.Windows.Forms.Label();
            num4_4 = new System.Windows.Forms.TextBox();
            label24 = new System.Windows.Forms.Label();
            num4_2 = new System.Windows.Forms.TextBox();
            num4_1 = new System.Windows.Forms.TextBox();
            groupBox6 = new System.Windows.Forms.GroupBox();
            groupBox7 = new System.Windows.Forms.GroupBox();
            label31 = new System.Windows.Forms.Label();
            comboBox6 = new System.Windows.Forms.ComboBox();
            label32 = new System.Windows.Forms.Label();
            label33 = new System.Windows.Forms.Label();
            textBox21 = new System.Windows.Forms.TextBox();
            textBox22 = new System.Windows.Forms.TextBox();
            label34 = new System.Windows.Forms.Label();
            label35 = new System.Windows.Forms.Label();
            textBox23 = new System.Windows.Forms.TextBox();
            label36 = new System.Windows.Forms.Label();
            textBox24 = new System.Windows.Forms.TextBox();
            textBox25 = new System.Windows.Forms.TextBox();
            label37 = new System.Windows.Forms.Label();
            comboBox7 = new System.Windows.Forms.ComboBox();
            label38 = new System.Windows.Forms.Label();
            label39 = new System.Windows.Forms.Label();
            exam_num5 = new System.Windows.Forms.TextBox();
            num5_3 = new System.Windows.Forms.TextBox();
            label40 = new System.Windows.Forms.Label();
            label41 = new System.Windows.Forms.Label();
            num5_4 = new System.Windows.Forms.TextBox();
            label42 = new System.Windows.Forms.Label();
            num5_2 = new System.Windows.Forms.TextBox();
            num5_1 = new System.Windows.Forms.TextBox();
            button3 = new System.Windows.Forms.Button();
            button4 = new System.Windows.Forms.Button();
            button5 = new System.Windows.Forms.Button();
            groupBox9 = new System.Windows.Forms.GroupBox();
            button2 = new System.Windows.Forms.Button();
            insert_button = new System.Windows.Forms.Button();
            button_road = new System.Windows.Forms.Button();
            submit_button = new System.Windows.Forms.Button();
            delete_button = new System.Windows.Forms.Button();
            groupBox8 = new System.Windows.Forms.GroupBox();
            groupBox5 = new System.Windows.Forms.GroupBox();
            label25 = new System.Windows.Forms.Label();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            groupBox3.SuspendLayout();
            groupBox4.SuspendLayout();
            groupBox6.SuspendLayout();
            groupBox7.SuspendLayout();
            groupBox9.SuspendLayout();
            groupBox8.SuspendLayout();
            SuspendLayout();
            // 
            // exam_num1
            // 
            exam_num1.Location = new System.Drawing.Point(46, 54);
            exam_num1.Name = "exam_num1";
            exam_num1.Size = new System.Drawing.Size(710, 23);
            exam_num1.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label1.Location = new System.Drawing.Point(2, 57);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(42, 15);
            label1.TabIndex = 2;
            label1.Text = "문제 1";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new System.Drawing.Point(6, 125);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(17, 15);
            label2.TabIndex = 3;
            label2.Text = "1.";
            // 
            // groupBox1
            // 
            groupBox1.BackColor = System.Drawing.Color.FromArgb(224, 224, 224);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(comboBox1);
            groupBox1.Controls.Add(label1);
            groupBox1.Controls.Add(label7);
            groupBox1.Controls.Add(exam_num1);
            groupBox1.Controls.Add(num1_3);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(num1_4);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(num1_2);
            groupBox1.Controls.Add(num1_1);
            groupBox1.Location = new System.Drawing.Point(4, 49);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new System.Drawing.Size(762, 242);
            groupBox1.TabIndex = 4;
            groupBox1.TabStop = false;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new System.Drawing.Point(7, 199);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(31, 15);
            label3.TabIndex = 11;
            label3.Text = "정답";
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "1", "2", "3", "4" });
            comboBox1.Location = new System.Drawing.Point(42, 196);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new System.Drawing.Size(89, 23);
            comboBox1.TabIndex = 10;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new System.Drawing.Point(6, 151);
            label7.Name = "label7";
            label7.Size = new System.Drawing.Size(17, 15);
            label7.TabIndex = 9;
            label7.Text = "3.";
            // 
            // num1_3
            // 
            num1_3.Location = new System.Drawing.Point(26, 151);
            num1_3.Name = "num1_3";
            num1_3.Size = new System.Drawing.Size(344, 23);
            num1_3.TabIndex = 5;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new System.Drawing.Point(393, 154);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(17, 15);
            label5.TabIndex = 7;
            label5.Text = "4.";
            // 
            // num1_4
            // 
            num1_4.Location = new System.Drawing.Point(416, 151);
            num1_4.Name = "num1_4";
            num1_4.Size = new System.Drawing.Size(338, 23);
            num1_4.TabIndex = 8;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new System.Drawing.Point(393, 125);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(17, 15);
            label4.TabIndex = 5;
            label4.Text = "2.";
            // 
            // num1_2
            // 
            num1_2.Location = new System.Drawing.Point(416, 122);
            num1_2.Name = "num1_2";
            num1_2.Size = new System.Drawing.Size(338, 23);
            num1_2.TabIndex = 5;
            // 
            // num1_1
            // 
            num1_1.Location = new System.Drawing.Point(26, 122);
            num1_1.Name = "num1_1";
            num1_1.Size = new System.Drawing.Size(344, 23);
            num1_1.TabIndex = 0;
            // 
            // button1
            // 
            button1.BackgroundImage = (System.Drawing.Image)resources.GetObject("button1.BackgroundImage");
            button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            button1.Location = new System.Drawing.Point(1121, -608);
            button1.Name = "button1";
            button1.Size = new System.Drawing.Size(41, 36);
            button1.TabIndex = 17;
            button1.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            groupBox2.BackColor = System.Drawing.Color.FromArgb(224, 224, 224);
            groupBox2.Controls.Add(label6);
            groupBox2.Controls.Add(comboBox2);
            groupBox2.Controls.Add(label8);
            groupBox2.Controls.Add(label9);
            groupBox2.Controls.Add(exam_num2);
            groupBox2.Controls.Add(num2_3);
            groupBox2.Controls.Add(label10);
            groupBox2.Controls.Add(label11);
            groupBox2.Controls.Add(num2_4);
            groupBox2.Controls.Add(label12);
            groupBox2.Controls.Add(num2_2);
            groupBox2.Controls.Add(num2_1);
            groupBox2.Location = new System.Drawing.Point(4, 339);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new System.Drawing.Size(762, 242);
            groupBox2.TabIndex = 12;
            groupBox2.TabStop = false;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new System.Drawing.Point(7, 199);
            label6.Name = "label6";
            label6.Size = new System.Drawing.Size(31, 15);
            label6.TabIndex = 11;
            label6.Text = "정답";
            // 
            // comboBox2
            // 
            comboBox2.FormattingEnabled = true;
            comboBox2.Items.AddRange(new object[] { "1", "2", "3", "4" });
            comboBox2.Location = new System.Drawing.Point(42, 196);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new System.Drawing.Size(89, 23);
            comboBox2.TabIndex = 10;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label8.Location = new System.Drawing.Point(2, 57);
            label8.Name = "label8";
            label8.Size = new System.Drawing.Size(42, 15);
            label8.TabIndex = 2;
            label8.Text = "문제 2";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new System.Drawing.Point(6, 151);
            label9.Name = "label9";
            label9.Size = new System.Drawing.Size(17, 15);
            label9.TabIndex = 9;
            label9.Text = "3.";
            // 
            // exam_num2
            // 
            exam_num2.Location = new System.Drawing.Point(46, 54);
            exam_num2.Name = "exam_num2";
            exam_num2.Size = new System.Drawing.Size(708, 23);
            exam_num2.TabIndex = 1;
            // 
            // num2_3
            // 
            num2_3.Location = new System.Drawing.Point(26, 151);
            num2_3.Name = "num2_3";
            num2_3.Size = new System.Drawing.Size(344, 23);
            num2_3.TabIndex = 5;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new System.Drawing.Point(6, 125);
            label10.Name = "label10";
            label10.Size = new System.Drawing.Size(17, 15);
            label10.TabIndex = 3;
            label10.Text = "1.";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new System.Drawing.Point(393, 154);
            label11.Name = "label11";
            label11.Size = new System.Drawing.Size(17, 15);
            label11.TabIndex = 7;
            label11.Text = "4.";
            // 
            // num2_4
            // 
            num2_4.Location = new System.Drawing.Point(416, 151);
            num2_4.Name = "num2_4";
            num2_4.Size = new System.Drawing.Size(338, 23);
            num2_4.TabIndex = 8;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new System.Drawing.Point(393, 125);
            label12.Name = "label12";
            label12.Size = new System.Drawing.Size(17, 15);
            label12.TabIndex = 5;
            label12.Text = "2.";
            // 
            // num2_2
            // 
            num2_2.Location = new System.Drawing.Point(416, 122);
            num2_2.Name = "num2_2";
            num2_2.Size = new System.Drawing.Size(338, 23);
            num2_2.TabIndex = 5;
            // 
            // num2_1
            // 
            num2_1.Location = new System.Drawing.Point(26, 122);
            num2_1.Name = "num2_1";
            num2_1.Size = new System.Drawing.Size(344, 23);
            num2_1.TabIndex = 0;
            // 
            // groupBox3
            // 
            groupBox3.BackColor = System.Drawing.Color.FromArgb(224, 224, 224);
            groupBox3.Controls.Add(label13);
            groupBox3.Controls.Add(comboBox3);
            groupBox3.Controls.Add(label14);
            groupBox3.Controls.Add(label15);
            groupBox3.Controls.Add(exam_num3);
            groupBox3.Controls.Add(num3_3);
            groupBox3.Controls.Add(label16);
            groupBox3.Controls.Add(label17);
            groupBox3.Controls.Add(num3_4);
            groupBox3.Controls.Add(label18);
            groupBox3.Controls.Add(num3_2);
            groupBox3.Controls.Add(num3_1);
            groupBox3.Location = new System.Drawing.Point(4, 628);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new System.Drawing.Size(762, 242);
            groupBox3.TabIndex = 19;
            groupBox3.TabStop = false;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new System.Drawing.Point(7, 199);
            label13.Name = "label13";
            label13.Size = new System.Drawing.Size(31, 15);
            label13.TabIndex = 11;
            label13.Text = "정답";
            // 
            // comboBox3
            // 
            comboBox3.FormattingEnabled = true;
            comboBox3.Items.AddRange(new object[] { "1", "2", "3", "4" });
            comboBox3.Location = new System.Drawing.Point(42, 196);
            comboBox3.Name = "comboBox3";
            comboBox3.Size = new System.Drawing.Size(89, 23);
            comboBox3.TabIndex = 10;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label14.Location = new System.Drawing.Point(2, 57);
            label14.Name = "label14";
            label14.Size = new System.Drawing.Size(42, 15);
            label14.TabIndex = 2;
            label14.Text = "문제 3";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new System.Drawing.Point(6, 151);
            label15.Name = "label15";
            label15.Size = new System.Drawing.Size(17, 15);
            label15.TabIndex = 9;
            label15.Text = "3.";
            // 
            // exam_num3
            // 
            exam_num3.Location = new System.Drawing.Point(46, 54);
            exam_num3.Name = "exam_num3";
            exam_num3.Size = new System.Drawing.Size(710, 23);
            exam_num3.TabIndex = 1;
            // 
            // num3_3
            // 
            num3_3.Location = new System.Drawing.Point(26, 151);
            num3_3.Name = "num3_3";
            num3_3.Size = new System.Drawing.Size(344, 23);
            num3_3.TabIndex = 5;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Location = new System.Drawing.Point(6, 125);
            label16.Name = "label16";
            label16.Size = new System.Drawing.Size(17, 15);
            label16.TabIndex = 3;
            label16.Text = "1.";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Location = new System.Drawing.Point(393, 154);
            label17.Name = "label17";
            label17.Size = new System.Drawing.Size(17, 15);
            label17.TabIndex = 7;
            label17.Text = "4.";
            // 
            // num3_4
            // 
            num3_4.Location = new System.Drawing.Point(416, 151);
            num3_4.Name = "num3_4";
            num3_4.Size = new System.Drawing.Size(338, 23);
            num3_4.TabIndex = 8;
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Location = new System.Drawing.Point(393, 125);
            label18.Name = "label18";
            label18.Size = new System.Drawing.Size(17, 15);
            label18.TabIndex = 5;
            label18.Text = "2.";
            // 
            // num3_2
            // 
            num3_2.Location = new System.Drawing.Point(416, 122);
            num3_2.Name = "num3_2";
            num3_2.Size = new System.Drawing.Size(338, 23);
            num3_2.TabIndex = 5;
            // 
            // num3_1
            // 
            num3_1.Location = new System.Drawing.Point(26, 122);
            num3_1.Name = "num3_1";
            num3_1.Size = new System.Drawing.Size(344, 23);
            num3_1.TabIndex = 0;
            // 
            // groupBox4
            // 
            groupBox4.BackColor = System.Drawing.Color.FromArgb(224, 224, 224);
            groupBox4.Controls.Add(label19);
            groupBox4.Controls.Add(comboBox4);
            groupBox4.Controls.Add(label20);
            groupBox4.Controls.Add(label21);
            groupBox4.Controls.Add(exam_num4);
            groupBox4.Controls.Add(num4_3);
            groupBox4.Controls.Add(label22);
            groupBox4.Controls.Add(label23);
            groupBox4.Controls.Add(num4_4);
            groupBox4.Controls.Add(label24);
            groupBox4.Controls.Add(num4_2);
            groupBox4.Controls.Add(num4_1);
            groupBox4.Location = new System.Drawing.Point(4, 911);
            groupBox4.Name = "groupBox4";
            groupBox4.Size = new System.Drawing.Size(760, 242);
            groupBox4.TabIndex = 12;
            groupBox4.TabStop = false;
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Location = new System.Drawing.Point(7, 199);
            label19.Name = "label19";
            label19.Size = new System.Drawing.Size(31, 15);
            label19.TabIndex = 11;
            label19.Text = "정답";
            // 
            // comboBox4
            // 
            comboBox4.FormattingEnabled = true;
            comboBox4.Items.AddRange(new object[] { "1", "2", "3", "4" });
            comboBox4.Location = new System.Drawing.Point(42, 196);
            comboBox4.Name = "comboBox4";
            comboBox4.Size = new System.Drawing.Size(89, 23);
            comboBox4.TabIndex = 10;
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label20.Location = new System.Drawing.Point(2, 57);
            label20.Name = "label20";
            label20.Size = new System.Drawing.Size(42, 15);
            label20.TabIndex = 2;
            label20.Text = "문제 4";
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Location = new System.Drawing.Point(6, 151);
            label21.Name = "label21";
            label21.Size = new System.Drawing.Size(17, 15);
            label21.TabIndex = 9;
            label21.Text = "3.";
            // 
            // exam_num4
            // 
            exam_num4.Location = new System.Drawing.Point(46, 54);
            exam_num4.Name = "exam_num4";
            exam_num4.Size = new System.Drawing.Size(708, 23);
            exam_num4.TabIndex = 1;
            // 
            // num4_3
            // 
            num4_3.Location = new System.Drawing.Point(26, 151);
            num4_3.Name = "num4_3";
            num4_3.Size = new System.Drawing.Size(344, 23);
            num4_3.TabIndex = 5;
            // 
            // label22
            // 
            label22.AutoSize = true;
            label22.Location = new System.Drawing.Point(6, 125);
            label22.Name = "label22";
            label22.Size = new System.Drawing.Size(17, 15);
            label22.TabIndex = 3;
            label22.Text = "1.";
            // 
            // label23
            // 
            label23.AutoSize = true;
            label23.Location = new System.Drawing.Point(393, 154);
            label23.Name = "label23";
            label23.Size = new System.Drawing.Size(17, 15);
            label23.TabIndex = 7;
            label23.Text = "4.";
            // 
            // num4_4
            // 
            num4_4.Location = new System.Drawing.Point(416, 151);
            num4_4.Name = "num4_4";
            num4_4.Size = new System.Drawing.Size(338, 23);
            num4_4.TabIndex = 8;
            // 
            // label24
            // 
            label24.AutoSize = true;
            label24.Location = new System.Drawing.Point(393, 125);
            label24.Name = "label24";
            label24.Size = new System.Drawing.Size(17, 15);
            label24.TabIndex = 5;
            label24.Text = "2.";
            // 
            // num4_2
            // 
            num4_2.Location = new System.Drawing.Point(416, 122);
            num4_2.Name = "num4_2";
            num4_2.Size = new System.Drawing.Size(338, 23);
            num4_2.TabIndex = 5;
            // 
            // num4_1
            // 
            num4_1.Location = new System.Drawing.Point(26, 122);
            num4_1.Name = "num4_1";
            num4_1.Size = new System.Drawing.Size(344, 23);
            num4_1.TabIndex = 0;
            // 
            // groupBox6
            // 
            groupBox6.BackColor = System.Drawing.Color.FromArgb(224, 224, 224);
            groupBox6.Controls.Add(groupBox7);
            groupBox6.Controls.Add(label37);
            groupBox6.Controls.Add(comboBox7);
            groupBox6.Controls.Add(label38);
            groupBox6.Controls.Add(label39);
            groupBox6.Controls.Add(exam_num5);
            groupBox6.Controls.Add(num5_3);
            groupBox6.Controls.Add(label40);
            groupBox6.Controls.Add(label41);
            groupBox6.Controls.Add(num5_4);
            groupBox6.Controls.Add(label42);
            groupBox6.Controls.Add(num5_2);
            groupBox6.Controls.Add(num5_1);
            groupBox6.Location = new System.Drawing.Point(4, 1190);
            groupBox6.Name = "groupBox6";
            groupBox6.Size = new System.Drawing.Size(760, 242);
            groupBox6.TabIndex = 14;
            groupBox6.TabStop = false;
            // 
            // groupBox7
            // 
            groupBox7.Controls.Add(label31);
            groupBox7.Controls.Add(comboBox6);
            groupBox7.Controls.Add(label32);
            groupBox7.Controls.Add(label33);
            groupBox7.Controls.Add(textBox21);
            groupBox7.Controls.Add(textBox22);
            groupBox7.Controls.Add(label34);
            groupBox7.Controls.Add(label35);
            groupBox7.Controls.Add(textBox23);
            groupBox7.Controls.Add(label36);
            groupBox7.Controls.Add(textBox24);
            groupBox7.Controls.Add(textBox25);
            groupBox7.Location = new System.Drawing.Point(0, 248);
            groupBox7.Name = "groupBox7";
            groupBox7.Size = new System.Drawing.Size(770, 242);
            groupBox7.TabIndex = 13;
            groupBox7.TabStop = false;
            // 
            // label31
            // 
            label31.AutoSize = true;
            label31.Location = new System.Drawing.Point(7, 199);
            label31.Name = "label31";
            label31.Size = new System.Drawing.Size(31, 15);
            label31.TabIndex = 11;
            label31.Text = "정답";
            // 
            // comboBox6
            // 
            comboBox6.FormattingEnabled = true;
            comboBox6.Items.AddRange(new object[] { "1번", "2번", "3번", "4번" });
            comboBox6.Location = new System.Drawing.Point(42, 196);
            comboBox6.Name = "comboBox6";
            comboBox6.Size = new System.Drawing.Size(89, 23);
            comboBox6.TabIndex = 10;
            // 
            // label32
            // 
            label32.AutoSize = true;
            label32.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label32.Location = new System.Drawing.Point(2, 57);
            label32.Name = "label32";
            label32.Size = new System.Drawing.Size(42, 15);
            label32.TabIndex = 2;
            label32.Text = "문제 1";
            // 
            // label33
            // 
            label33.AutoSize = true;
            label33.Location = new System.Drawing.Point(6, 151);
            label33.Name = "label33";
            label33.Size = new System.Drawing.Size(17, 15);
            label33.TabIndex = 9;
            label33.Text = "3.";
            // 
            // textBox21
            // 
            textBox21.Location = new System.Drawing.Point(46, 54);
            textBox21.Name = "textBox21";
            textBox21.Size = new System.Drawing.Size(718, 23);
            textBox21.TabIndex = 1;
            // 
            // textBox22
            // 
            textBox22.Location = new System.Drawing.Point(26, 151);
            textBox22.Name = "textBox22";
            textBox22.Size = new System.Drawing.Size(344, 23);
            textBox22.TabIndex = 5;
            // 
            // label34
            // 
            label34.AutoSize = true;
            label34.Location = new System.Drawing.Point(6, 125);
            label34.Name = "label34";
            label34.Size = new System.Drawing.Size(17, 15);
            label34.TabIndex = 3;
            label34.Text = "1.";
            // 
            // label35
            // 
            label35.AutoSize = true;
            label35.Location = new System.Drawing.Point(393, 154);
            label35.Name = "label35";
            label35.Size = new System.Drawing.Size(17, 15);
            label35.TabIndex = 7;
            label35.Text = "4.";
            // 
            // textBox23
            // 
            textBox23.Location = new System.Drawing.Point(416, 151);
            textBox23.Name = "textBox23";
            textBox23.Size = new System.Drawing.Size(338, 23);
            textBox23.TabIndex = 8;
            // 
            // label36
            // 
            label36.AutoSize = true;
            label36.Location = new System.Drawing.Point(393, 125);
            label36.Name = "label36";
            label36.Size = new System.Drawing.Size(17, 15);
            label36.TabIndex = 5;
            label36.Text = "2.";
            // 
            // textBox24
            // 
            textBox24.Location = new System.Drawing.Point(416, 122);
            textBox24.Name = "textBox24";
            textBox24.Size = new System.Drawing.Size(338, 23);
            textBox24.TabIndex = 5;
            // 
            // textBox25
            // 
            textBox25.Location = new System.Drawing.Point(26, 122);
            textBox25.Name = "textBox25";
            textBox25.Size = new System.Drawing.Size(344, 23);
            textBox25.TabIndex = 0;
            // 
            // label37
            // 
            label37.AutoSize = true;
            label37.Location = new System.Drawing.Point(7, 199);
            label37.Name = "label37";
            label37.Size = new System.Drawing.Size(31, 15);
            label37.TabIndex = 11;
            label37.Text = "정답";
            // 
            // comboBox7
            // 
            comboBox7.FormattingEnabled = true;
            comboBox7.Items.AddRange(new object[] { "1", "2", "3", "4" });
            comboBox7.Location = new System.Drawing.Point(42, 196);
            comboBox7.Name = "comboBox7";
            comboBox7.Size = new System.Drawing.Size(89, 23);
            comboBox7.TabIndex = 10;
            // 
            // label38
            // 
            label38.AutoSize = true;
            label38.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label38.Location = new System.Drawing.Point(2, 57);
            label38.Name = "label38";
            label38.Size = new System.Drawing.Size(42, 15);
            label38.TabIndex = 2;
            label38.Text = "문제 5";
            // 
            // label39
            // 
            label39.AutoSize = true;
            label39.Location = new System.Drawing.Point(6, 151);
            label39.Name = "label39";
            label39.Size = new System.Drawing.Size(17, 15);
            label39.TabIndex = 9;
            label39.Text = "3.";
            // 
            // exam_num5
            // 
            exam_num5.Location = new System.Drawing.Point(46, 54);
            exam_num5.Name = "exam_num5";
            exam_num5.Size = new System.Drawing.Size(708, 23);
            exam_num5.TabIndex = 1;
            // 
            // num5_3
            // 
            num5_3.Location = new System.Drawing.Point(26, 151);
            num5_3.Name = "num5_3";
            num5_3.Size = new System.Drawing.Size(344, 23);
            num5_3.TabIndex = 5;
            // 
            // label40
            // 
            label40.AutoSize = true;
            label40.Location = new System.Drawing.Point(6, 125);
            label40.Name = "label40";
            label40.Size = new System.Drawing.Size(17, 15);
            label40.TabIndex = 3;
            label40.Text = "1.";
            // 
            // label41
            // 
            label41.AutoSize = true;
            label41.Location = new System.Drawing.Point(393, 154);
            label41.Name = "label41";
            label41.Size = new System.Drawing.Size(17, 15);
            label41.TabIndex = 7;
            label41.Text = "4.";
            // 
            // num5_4
            // 
            num5_4.Location = new System.Drawing.Point(416, 151);
            num5_4.Name = "num5_4";
            num5_4.Size = new System.Drawing.Size(338, 23);
            num5_4.TabIndex = 8;
            // 
            // label42
            // 
            label42.AutoSize = true;
            label42.Location = new System.Drawing.Point(393, 125);
            label42.Name = "label42";
            label42.Size = new System.Drawing.Size(17, 15);
            label42.TabIndex = 5;
            label42.Text = "2.";
            // 
            // num5_2
            // 
            num5_2.Location = new System.Drawing.Point(416, 122);
            num5_2.Name = "num5_2";
            num5_2.Size = new System.Drawing.Size(338, 23);
            num5_2.TabIndex = 5;
            // 
            // num5_1
            // 
            num5_1.Location = new System.Drawing.Point(26, 122);
            num5_1.Name = "num5_1";
            num5_1.Size = new System.Drawing.Size(344, 23);
            num5_1.TabIndex = 0;
            // 
            // button3
            // 
            button3.BackgroundImage = (System.Drawing.Image)resources.GetObject("button3.BackgroundImage");
            button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            button3.FlatAppearance.BorderSize = 0;
            button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            button3.Location = new System.Drawing.Point(10, 1);
            button3.Name = "button3";
            button3.Size = new System.Drawing.Size(376, 72);
            button3.TabIndex = 20;
            button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            button4.BackgroundImage = (System.Drawing.Image)resources.GetObject("button4.BackgroundImage");
            button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            button4.FlatAppearance.BorderSize = 0;
            button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            button4.Location = new System.Drawing.Point(46, 23);
            button4.Name = "button4";
            button4.Size = new System.Drawing.Size(273, 115);
            button4.TabIndex = 22;
            button4.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            button5.BackgroundImage = (System.Drawing.Image)resources.GetObject("button5.BackgroundImage");
            button5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            button5.FlatAppearance.BorderSize = 0;
            button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            button5.Location = new System.Drawing.Point(46, 149);
            button5.Name = "button5";
            button5.Size = new System.Drawing.Size(273, 231);
            button5.TabIndex = 23;
            button5.UseVisualStyleBackColor = true;
            // 
            // groupBox9
            // 
            groupBox9.BackColor = System.Drawing.Color.FromArgb(192, 255, 192);
            groupBox9.Controls.Add(button2);
            groupBox9.Controls.Add(button5);
            groupBox9.Controls.Add(insert_button);
            groupBox9.Controls.Add(button4);
            groupBox9.Controls.Add(button_road);
            groupBox9.Controls.Add(submit_button);
            groupBox9.Controls.Add(delete_button);
            groupBox9.Location = new System.Drawing.Point(786, 82);
            groupBox9.Name = "groupBox9";
            groupBox9.Size = new System.Drawing.Size(376, 1460);
            groupBox9.TabIndex = 24;
            groupBox9.TabStop = false;
            // 
            // button2
            // 
            button2.BackgroundImage = (System.Drawing.Image)resources.GetObject("button2.BackgroundImage");
            button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            button2.FlatAppearance.BorderSize = 0;
            button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            button2.Location = new System.Drawing.Point(46, 421);
            button2.Name = "button2";
            button2.Size = new System.Drawing.Size(273, 209);
            button2.TabIndex = 27;
            button2.UseVisualStyleBackColor = true;
            // 
            // insert_button
            // 
            insert_button.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            insert_button.Location = new System.Drawing.Point(233, 1339);
            insert_button.Name = "insert_button";
            insert_button.Size = new System.Drawing.Size(121, 34);
            insert_button.TabIndex = 26;
            insert_button.Text = "문제 수정하기";
            insert_button.UseVisualStyleBackColor = true;
            insert_button.Click += button6_Click;
            // 
            // button_road
            // 
            button_road.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            button_road.Location = new System.Drawing.Point(23, 1340);
            button_road.Name = "button_road";
            button_road.Size = new System.Drawing.Size(121, 34);
            button_road.TabIndex = 25;
            button_road.Text = "문제 불러오기";
            button_road.UseVisualStyleBackColor = true;
            button_road.Click += button_road_Click;
            // 
            // submit_button
            // 
            submit_button.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            submit_button.Location = new System.Drawing.Point(233, 1411);
            submit_button.Name = "submit_button";
            submit_button.Size = new System.Drawing.Size(121, 34);
            submit_button.TabIndex = 18;
            submit_button.Text = "문제 제출";
            submit_button.UseVisualStyleBackColor = true;
            submit_button.Click += button2_Click;
            // 
            // delete_button
            // 
            delete_button.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            delete_button.Font = new System.Drawing.Font("맑은 고딕", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            delete_button.Location = new System.Drawing.Point(24, 1409);
            delete_button.Name = "delete_button";
            delete_button.Size = new System.Drawing.Size(121, 34);
            delete_button.TabIndex = 19;
            delete_button.Text = "데이터 삭제";
            delete_button.UseVisualStyleBackColor = true;
            delete_button.Click += delete_button_Click;
            // 
            // groupBox8
            // 
            groupBox8.BackColor = System.Drawing.Color.Silver;
            groupBox8.Controls.Add(groupBox6);
            groupBox8.Controls.Add(groupBox4);
            groupBox8.Controls.Add(groupBox3);
            groupBox8.Controls.Add(groupBox2);
            groupBox8.Controls.Add(groupBox1);
            groupBox8.Location = new System.Drawing.Point(4, 83);
            groupBox8.Name = "groupBox8";
            groupBox8.Size = new System.Drawing.Size(772, 1459);
            groupBox8.TabIndex = 21;
            groupBox8.TabStop = false;
            // 
            // groupBox5
            // 
            groupBox5.BackColor = System.Drawing.Color.Black;
            groupBox5.Location = new System.Drawing.Point(10, 67);
            groupBox5.Name = "groupBox5";
            groupBox5.Size = new System.Drawing.Size(1150, 3);
            groupBox5.TabIndex = 32;
            groupBox5.TabStop = false;
            // 
            // label25
            // 
            label25.AutoSize = true;
            label25.Font = new System.Drawing.Font("맑은 고딕", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            label25.ForeColor = System.Drawing.Color.Blue;
            label25.Location = new System.Drawing.Point(1053, 21);
            label25.Name = "label25";
            label25.Size = new System.Drawing.Size(97, 30);
            label25.TabIndex = 33;
            label25.Text = "출제자용";
            // 
            // Form1
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            AutoScroll = true;
            AutoScrollMinSize = new System.Drawing.Size(0, 1550);
            AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            BackColor = System.Drawing.Color.White;
            ClientSize = new System.Drawing.Size(1184, 761);
            Controls.Add(label25);
            Controls.Add(groupBox5);
            Controls.Add(button1);
            Controls.Add(groupBox8);
            Controls.Add(groupBox9);
            Controls.Add(button3);
            Name = "Form1";
            Text = "Form1";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            groupBox4.ResumeLayout(false);
            groupBox4.PerformLayout();
            groupBox6.ResumeLayout(false);
            groupBox6.PerformLayout();
            groupBox7.ResumeLayout(false);
            groupBox7.PerformLayout();
            groupBox9.ResumeLayout(false);
            groupBox8.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private System.Windows.Forms.TextBox exam_num1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox num1_3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox num1_4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox num1_2;
        private System.Windows.Forms.TextBox num1_1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox exam_num2;
        private System.Windows.Forms.TextBox num2_3;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox num2_4;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox num2_2;
        private System.Windows.Forms.TextBox num2_1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox exam_num3;
        private System.Windows.Forms.TextBox num3_3;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox num3_4;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox num3_2;
        private System.Windows.Forms.TextBox num3_1;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox exam_num4;
        private System.Windows.Forms.TextBox num4_3;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox num4_4;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox num4_2;
        private System.Windows.Forms.TextBox num4_1;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.ComboBox comboBox6;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.ComboBox comboBox7;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox exam_num5;
        private System.Windows.Forms.TextBox num5_3;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox num5_4;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TextBox num5_2;
        private System.Windows.Forms.TextBox num5_1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Button submit_button;
        private System.Windows.Forms.Button delete_button;
        private System.Windows.Forms.Button button_road;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Button insert_button;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label25;
    }
}
