﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TestForm
{

    public partial class Form8 : Form
    {        
        static string constr = "Server=localhost;Port=3306;Database=test;Uid=root;Pwd=0000";
        static string constr1 = "Server=localhost;Port=3306;Database=test_score;Uid=root;Pwd=0000";

        static MySqlConnection connection = new MySqlConnection(constr);
        static MySqlConnection connection1 = new MySqlConnection(constr1);

        List<RadioButton> radioButton_1;
        List<RadioButton> radioButton_2;
        List<RadioButton> radioButton_3;
        List<RadioButton> radioButton_4;

        List<int> string_answer;
        List<string> list;
       
        public Form8()
        {
            InitializeComponent();       
            textBox1.Enabled= false;
            textBox2.Enabled = false;
            textBox3.Enabled = false;
            textBox4.Enabled = false;
            textBox5.Enabled = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            string[] str_spl;
            str_spl=textBox2.Text.Split(',');
            string insertQuery = string.Format("INSERT INTO new_table(exam_problem,exam_answer1,exam_answer2,exam_answer3,exam_answer4,exam_org_answer) VALUES('{0}','{1}','{2}','{3}','{4}','{5}')", str_spl[0], str_spl[1], str_spl[2], str_spl[3], str_spl[4], str_spl[5]);
          
            MySqlCommand command = new MySqlCommand(insertQuery, connection);
           
            try//예외 처리
            {
                
                connection.Open();
                if (command.ExecuteNonQuery() == 1)
                {
                    textBox1.Text = "인서트 성공";
                }                
                else
                {
                    textBox1.Text = "인서트 실패";
                }
                
            }
            catch (Exception ex)
            {
                textBox1.Text = "실패";
                MessageBox.Show(ex.ToString());
            }
            textBox2.Text = "";
        }

        public void button2_Click(object sender, EventArgs e)
        {
            string Query = "SELECT * FROM test.new_table";
            MySqlCommand command = new MySqlCommand(Query, connection);

            List<string> string_first = new List<string>();
            List<string> string_second = new List<string>();
            List<string> string_third = new List<string>();
            List<string> string_fourth = new List<string>();
            List<string> string_text = new List<string>();
            string_answer = new List<int>();

            List<TextBox> textBox = new List<TextBox>() { textBox1, textBox2, textBox3, textBox4, textBox5 };
            
            radioButton_1 = new List<RadioButton>() { first1_1, first1_2, first1_3, first1_4, first1_5 };
            radioButton_2 = new List<RadioButton>() { sec2_1, sec2_2, sec2_3, sec2_4, sec2_5 };
            radioButton_3 = new List<RadioButton>() { th3_1, th3_2, th3_3, th3_4, th3_5 };
            radioButton_4 = new List<RadioButton>() { four4_1, four4_2, four4_3, four4_4, four4_5 };
           
            int count = 0;
            try//예외 처리
            {
                connection.Open();
                MySqlDataReader MyReader = command.ExecuteReader();
                while (MyReader.Read())
                {
                    string s_text = MyReader.GetString("exam_problem");
                    string s_first = MyReader.GetString("exam_answer1");
                    string s_second = MyReader.GetString("exam_answer2");
                    string s_third = MyReader.GetString("exam_answer3");
                    string s_fourth = MyReader.GetString("exam_answer4");                    
                    int s_answer=MyReader.GetInt32("exam_org_answer");

                    string_text.Add(s_text);
                    string_first.Add(s_first);
                    string_second.Add(s_second);
                    string_third.Add(s_third);
                    string_fourth.Add(s_fourth);

                    string_answer.Add(s_answer);

                    textBox[count].Text = string_text[count];
                    radioButton_1[count].Text= string_first[count];
                    radioButton_2[count].Text = string_second[count];
                    radioButton_3[count].Text = string_third[count];
                    radioButton_4[count].Text = string_fourth[count];
                    count++;
                }
                
                //for (int j = 0; j < string_text.Count; j++)
                //{
                //    textBox1.Text += string_text[j] + string_first[j] + string_second[j] + string_third[j] + string_fourth[j];
                //    textBox1.Text += "         ";
                //}
            }
            catch (Exception ex)
            {
                textBox1.Text = "실패";
                MessageBox.Show(ex.ToString());
            }
                       
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string query_del = "delete from test_score.student_score where no";
            MySqlCommand command = new MySqlCommand(query_del, connection);
            MySqlDataReader myreader;
            try//예외 처리
            {
                connection.Open();

                myreader= command.ExecuteReader();
                MessageBox.Show("삭제됨");
            }
            catch (Exception ex)
            {
                textBox1.Text = "실패";
                MessageBox.Show(ex.ToString());
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {            
            list = new List<string>();           
            List<string> count = new List<string>();
           
            int score = 0;
                        
            for (int i = 0; i < radioButton_1.Count; i++)
            {
                if (radioButton_1[i].Checked)                
                    list.Add(radioButton_1[i].Text);                                   
                else if(radioButton_2[i].Checked)
                    list.Add(radioButton_2[i].Text);
                else if(radioButton_3[i].Checked)
                    list.Add(radioButton_3[i].Text);
                else 
                    list.Add(radioButton_4[i].Text);
            }
            //MessageBox.Show(string.Join(",",list));           

            string dot = string.Join(",", list);
            string[] str_spl;
            str_spl = dot.Split(",");
            int[] int_spl = Array.ConvertAll(str_spl, item => int.Parse(item));
            for (int i = 0; i < 5; i++)
                {
                    if (string_answer[i] == int_spl[i])
                    {
                        count.Add("O");
                        score += 20;
                    }
                    else
                        count.Add("X");
                }                                          
            string insertQuery = string.Format("INSERT INTO student_score(name,score,num1,num2,num3,num4,num5) VALUES('이재주','{0}','{1}','{2}','{3}','{4}','{5}')", score, count[0], count[1], count[2], count[3], count[4]);            
            MySqlCommand command = new MySqlCommand(insertQuery, connection1);                                   
           
            try//예외 처리
            {
                connection1.Open();                               

                if (command.ExecuteNonQuery() == 1)
                {
                    MessageBox.Show("출제 완료했습니다.");
                }
                else
                {
                    MessageBox.Show("실패");
                }

            }
            catch (Exception ex)
            {                
                MessageBox.Show(ex.ToString());
            }
        }

       
    }
}
