﻿namespace TestForm
{
    partial class Form8
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form8));
            this.first1_1 = new System.Windows.Forms.RadioButton();
            this.sec2_1 = new System.Windows.Forms.RadioButton();
            this.th3_1 = new System.Windows.Forms.RadioButton();
            this.four4_1 = new System.Windows.Forms.RadioButton();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.first1_2 = new System.Windows.Forms.RadioButton();
            this.sec2_2 = new System.Windows.Forms.RadioButton();
            this.th3_2 = new System.Windows.Forms.RadioButton();
            this.four4_2 = new System.Windows.Forms.RadioButton();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.first1_3 = new System.Windows.Forms.RadioButton();
            this.sec2_3 = new System.Windows.Forms.RadioButton();
            this.th3_3 = new System.Windows.Forms.RadioButton();
            this.four4_3 = new System.Windows.Forms.RadioButton();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.first1_5 = new System.Windows.Forms.RadioButton();
            this.sec2_5 = new System.Windows.Forms.RadioButton();
            this.th3_5 = new System.Windows.Forms.RadioButton();
            this.four4_5 = new System.Windows.Forms.RadioButton();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.first1_4 = new System.Windows.Forms.RadioButton();
            this.sec2_4 = new System.Windows.Forms.RadioButton();
            this.th3_4 = new System.Windows.Forms.RadioButton();
            this.four4_4 = new System.Windows.Forms.RadioButton();
            this.button4 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox7.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.SuspendLayout();
            // 
            // first1_1
            // 
            this.first1_1.AutoSize = true;
            this.first1_1.Location = new System.Drawing.Point(38, 22);
            this.first1_1.Name = "first1_1";
            this.first1_1.Size = new System.Drawing.Size(95, 19);
            this.first1_1.TabIndex = 0;
            this.first1_1.TabStop = true;
            this.first1_1.Text = "radioButton1";
            this.first1_1.UseVisualStyleBackColor = true;
            // 
            // sec2_1
            // 
            this.sec2_1.AutoSize = true;
            this.sec2_1.Location = new System.Drawing.Point(206, 22);
            this.sec2_1.Name = "sec2_1";
            this.sec2_1.Size = new System.Drawing.Size(95, 19);
            this.sec2_1.TabIndex = 1;
            this.sec2_1.TabStop = true;
            this.sec2_1.Text = "radioButton2";
            this.sec2_1.UseVisualStyleBackColor = true;
            // 
            // th3_1
            // 
            this.th3_1.AutoSize = true;
            this.th3_1.Location = new System.Drawing.Point(395, 22);
            this.th3_1.Name = "th3_1";
            this.th3_1.Size = new System.Drawing.Size(95, 19);
            this.th3_1.TabIndex = 2;
            this.th3_1.TabStop = true;
            this.th3_1.Text = "radioButton3";
            this.th3_1.UseVisualStyleBackColor = true;
            // 
            // four4_1
            // 
            this.four4_1.AutoSize = true;
            this.four4_1.Location = new System.Drawing.Point(581, 22);
            this.four4_1.Name = "four4_1";
            this.four4_1.Size = new System.Drawing.Size(95, 19);
            this.four4_1.TabIndex = 3;
            this.four4_1.TabStop = true;
            this.four4_1.Text = "radioButton4";
            this.four4_1.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(11, 22);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(677, 23);
            this.textBox1.TabIndex = 4;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(896, 686);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(93, 57);
            this.button2.TabIndex = 7;
            this.button2.Text = "값 읽어오기";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(16, 22);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(677, 23);
            this.textBox2.TabIndex = 4;
            // 
            // first1_2
            // 
            this.first1_2.AutoSize = true;
            this.first1_2.Location = new System.Drawing.Point(33, 21);
            this.first1_2.Name = "first1_2";
            this.first1_2.Size = new System.Drawing.Size(95, 19);
            this.first1_2.TabIndex = 9;
            this.first1_2.TabStop = true;
            this.first1_2.Text = "radioButton5";
            this.first1_2.UseVisualStyleBackColor = true;
            // 
            // sec2_2
            // 
            this.sec2_2.AutoSize = true;
            this.sec2_2.Location = new System.Drawing.Point(201, 21);
            this.sec2_2.Name = "sec2_2";
            this.sec2_2.Size = new System.Drawing.Size(95, 19);
            this.sec2_2.TabIndex = 9;
            this.sec2_2.TabStop = true;
            this.sec2_2.Text = "radioButton5";
            this.sec2_2.UseVisualStyleBackColor = true;
            // 
            // th3_2
            // 
            this.th3_2.AutoSize = true;
            this.th3_2.Location = new System.Drawing.Point(390, 21);
            this.th3_2.Name = "th3_2";
            this.th3_2.Size = new System.Drawing.Size(95, 19);
            this.th3_2.TabIndex = 9;
            this.th3_2.TabStop = true;
            this.th3_2.Text = "radioButton5";
            this.th3_2.UseVisualStyleBackColor = true;
            // 
            // four4_2
            // 
            this.four4_2.AutoSize = true;
            this.four4_2.Location = new System.Drawing.Point(576, 21);
            this.four4_2.Name = "four4_2";
            this.four4_2.Size = new System.Drawing.Size(95, 19);
            this.four4_2.TabIndex = 9;
            this.four4_2.TabStop = true;
            this.four4_2.Text = "radioButton5";
            this.four4_2.UseVisualStyleBackColor = true;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(16, 28);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(677, 23);
            this.textBox3.TabIndex = 4;
            // 
            // first1_3
            // 
            this.first1_3.AutoSize = true;
            this.first1_3.Location = new System.Drawing.Point(30, 22);
            this.first1_3.Name = "first1_3";
            this.first1_3.Size = new System.Drawing.Size(95, 19);
            this.first1_3.TabIndex = 9;
            this.first1_3.TabStop = true;
            this.first1_3.Text = "radioButton5";
            this.first1_3.UseVisualStyleBackColor = true;
            // 
            // sec2_3
            // 
            this.sec2_3.AutoSize = true;
            this.sec2_3.Location = new System.Drawing.Point(198, 22);
            this.sec2_3.Name = "sec2_3";
            this.sec2_3.Size = new System.Drawing.Size(95, 19);
            this.sec2_3.TabIndex = 9;
            this.sec2_3.TabStop = true;
            this.sec2_3.Text = "radioButton5";
            this.sec2_3.UseVisualStyleBackColor = true;
            // 
            // th3_3
            // 
            this.th3_3.AutoSize = true;
            this.th3_3.Location = new System.Drawing.Point(387, 22);
            this.th3_3.Name = "th3_3";
            this.th3_3.Size = new System.Drawing.Size(95, 19);
            this.th3_3.TabIndex = 9;
            this.th3_3.TabStop = true;
            this.th3_3.Text = "radioButton5";
            this.th3_3.UseVisualStyleBackColor = true;
            // 
            // four4_3
            // 
            this.four4_3.AutoSize = true;
            this.four4_3.Location = new System.Drawing.Point(573, 22);
            this.four4_3.Name = "four4_3";
            this.four4_3.Size = new System.Drawing.Size(95, 19);
            this.four4_3.TabIndex = 9;
            this.four4_3.TabStop = true;
            this.four4_3.Text = "radioButton5";
            this.four4_3.UseVisualStyleBackColor = true;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(16, 22);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(677, 23);
            this.textBox4.TabIndex = 4;
            // 
            // first1_5
            // 
            this.first1_5.AutoSize = true;
            this.first1_5.Location = new System.Drawing.Point(23, 16);
            this.first1_5.Name = "first1_5";
            this.first1_5.Size = new System.Drawing.Size(95, 19);
            this.first1_5.TabIndex = 9;
            this.first1_5.TabStop = true;
            this.first1_5.Text = "radioButton5";
            this.first1_5.UseVisualStyleBackColor = true;
            // 
            // sec2_5
            // 
            this.sec2_5.AutoSize = true;
            this.sec2_5.Location = new System.Drawing.Point(191, 16);
            this.sec2_5.Name = "sec2_5";
            this.sec2_5.Size = new System.Drawing.Size(95, 19);
            this.sec2_5.TabIndex = 9;
            this.sec2_5.TabStop = true;
            this.sec2_5.Text = "radioButton5";
            this.sec2_5.UseVisualStyleBackColor = true;
            // 
            // th3_5
            // 
            this.th3_5.AutoSize = true;
            this.th3_5.Location = new System.Drawing.Point(380, 16);
            this.th3_5.Name = "th3_5";
            this.th3_5.Size = new System.Drawing.Size(95, 19);
            this.th3_5.TabIndex = 9;
            this.th3_5.TabStop = true;
            this.th3_5.Text = "radioButton5";
            this.th3_5.UseVisualStyleBackColor = true;
            // 
            // four4_5
            // 
            this.four4_5.AutoSize = true;
            this.four4_5.Location = new System.Drawing.Point(572, 16);
            this.four4_5.Name = "four4_5";
            this.four4_5.Size = new System.Drawing.Size(95, 19);
            this.four4_5.TabIndex = 9;
            this.four4_5.TabStop = true;
            this.four4_5.Text = "radioButton5";
            this.four4_5.UseVisualStyleBackColor = true;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(16, 24);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(677, 23);
            this.textBox5.TabIndex = 4;
            // 
            // first1_4
            // 
            this.first1_4.AutoSize = true;
            this.first1_4.Location = new System.Drawing.Point(30, 10);
            this.first1_4.Name = "first1_4";
            this.first1_4.Size = new System.Drawing.Size(95, 19);
            this.first1_4.TabIndex = 9;
            this.first1_4.TabStop = true;
            this.first1_4.Text = "radioButton5";
            this.first1_4.UseVisualStyleBackColor = true;
            // 
            // sec2_4
            // 
            this.sec2_4.AutoSize = true;
            this.sec2_4.Location = new System.Drawing.Point(198, 10);
            this.sec2_4.Name = "sec2_4";
            this.sec2_4.Size = new System.Drawing.Size(95, 19);
            this.sec2_4.TabIndex = 9;
            this.sec2_4.TabStop = true;
            this.sec2_4.Text = "radioButton5";
            this.sec2_4.UseVisualStyleBackColor = true;
            // 
            // th3_4
            // 
            this.th3_4.AutoSize = true;
            this.th3_4.Location = new System.Drawing.Point(387, 10);
            this.th3_4.Name = "th3_4";
            this.th3_4.Size = new System.Drawing.Size(95, 19);
            this.th3_4.TabIndex = 9;
            this.th3_4.TabStop = true;
            this.th3_4.Text = "radioButton5";
            this.th3_4.UseVisualStyleBackColor = true;
            // 
            // four4_4
            // 
            this.four4_4.AutoSize = true;
            this.four4_4.Location = new System.Drawing.Point(579, 10);
            this.four4_4.Name = "four4_4";
            this.four4_4.Size = new System.Drawing.Size(95, 19);
            this.four4_4.TabIndex = 9;
            this.four4_4.TabStop = true;
            this.four4_4.Text = "radioButton5";
            this.four4_4.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(1038, 686);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(97, 57);
            this.button4.TabIndex = 8;
            this.button4.Text = "문제 제출";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.first1_1);
            this.groupBox1.Controls.Add(this.sec2_1);
            this.groupBox1.Controls.Add(this.th3_1);
            this.groupBox1.Controls.Add(this.four4_1);
            this.groupBox1.Location = new System.Drawing.Point(6, 50);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(761, 54);
            this.groupBox1.TabIndex = 12;
            this.groupBox1.TabStop = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(561, 24);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(14, 15);
            this.label4.TabIndex = 4;
            this.label4.Text = "4";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(375, 24);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(14, 15);
            this.label3.TabIndex = 4;
            this.label3.Text = "3";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(186, 24);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(14, 15);
            this.label2.TabIndex = 4;
            this.label2.Text = "2";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(18, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(14, 15);
            this.label1.TabIndex = 4;
            this.label1.Text = "1";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.first1_2);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.sec2_2);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.th3_2);
            this.groupBox2.Controls.Add(this.four4_2);
            this.groupBox2.Location = new System.Drawing.Point(8, 58);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(756, 46);
            this.groupBox2.TabIndex = 13;
            this.groupBox2.TabStop = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(556, 23);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(14, 15);
            this.label8.TabIndex = 4;
            this.label8.Text = "4";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(370, 23);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(14, 15);
            this.label7.TabIndex = 4;
            this.label7.Text = "3";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(181, 23);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(14, 15);
            this.label6.TabIndex = 4;
            this.label6.Text = "2";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(13, 23);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(14, 15);
            this.label5.TabIndex = 4;
            this.label5.Text = "1";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.first1_3);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.sec2_3);
            this.groupBox3.Controls.Add(this.th3_3);
            this.groupBox3.Controls.Add(this.label10);
            this.groupBox3.Controls.Add(this.four4_3);
            this.groupBox3.Controls.Add(this.label9);
            this.groupBox3.Location = new System.Drawing.Point(11, 57);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(753, 47);
            this.groupBox3.TabIndex = 14;
            this.groupBox3.TabStop = false;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(553, 24);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(14, 15);
            this.label12.TabIndex = 4;
            this.label12.Text = "4";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(367, 24);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(14, 15);
            this.label11.TabIndex = 4;
            this.label11.Text = "3";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(178, 24);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(14, 15);
            this.label10.TabIndex = 4;
            this.label10.Text = "2";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(10, 24);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(14, 15);
            this.label9.TabIndex = 4;
            this.label9.Text = "1";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label16);
            this.groupBox4.Controls.Add(this.label15);
            this.groupBox4.Controls.Add(this.four4_4);
            this.groupBox4.Controls.Add(this.th3_4);
            this.groupBox4.Controls.Add(this.label14);
            this.groupBox4.Controls.Add(this.sec2_4);
            this.groupBox4.Controls.Add(this.first1_4);
            this.groupBox4.Controls.Add(this.label13);
            this.groupBox4.Location = new System.Drawing.Point(11, 58);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(753, 46);
            this.groupBox4.TabIndex = 15;
            this.groupBox4.TabStop = false;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(559, 12);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(14, 15);
            this.label16.TabIndex = 4;
            this.label16.Text = "4";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(367, 12);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(14, 15);
            this.label15.TabIndex = 4;
            this.label15.Text = "3";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(178, 12);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(14, 15);
            this.label14.TabIndex = 4;
            this.label14.Text = "2";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(10, 12);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(14, 15);
            this.label13.TabIndex = 4;
            this.label13.Text = "1";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.label20);
            this.groupBox5.Controls.Add(this.first1_5);
            this.groupBox5.Controls.Add(this.label19);
            this.groupBox5.Controls.Add(this.sec2_5);
            this.groupBox5.Controls.Add(this.th3_5);
            this.groupBox5.Controls.Add(this.four4_5);
            this.groupBox5.Controls.Add(this.label18);
            this.groupBox5.Controls.Add(this.label17);
            this.groupBox5.Location = new System.Drawing.Point(18, 53);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(746, 41);
            this.groupBox5.TabIndex = 16;
            this.groupBox5.TabStop = false;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(552, 18);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(14, 15);
            this.label20.TabIndex = 4;
            this.label20.Text = "4";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(360, 16);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(14, 15);
            this.label19.TabIndex = 4;
            this.label19.Text = "3";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(171, 16);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(14, 15);
            this.label18.TabIndex = 4;
            this.label18.Text = "2";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(3, 16);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(14, 15);
            this.label17.TabIndex = 4;
            this.label17.Text = "1";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(1, -1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(401, 50);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 17;
            this.pictureBox1.TabStop = false;
            // 
            // groupBox6
            // 
            this.groupBox6.BackColor = System.Drawing.Color.Black;
            this.groupBox6.Location = new System.Drawing.Point(1, 46);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(1200, 3);
            this.groupBox6.TabIndex = 18;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "groupBox6";
            // 
            // groupBox7
            // 
            this.groupBox7.BackColor = System.Drawing.Color.DimGray;
            this.groupBox7.Controls.Add(this.groupBox12);
            this.groupBox7.Controls.Add(this.groupBox11);
            this.groupBox7.Controls.Add(this.groupBox10);
            this.groupBox7.Controls.Add(this.groupBox9);
            this.groupBox7.Controls.Add(this.groupBox8);
            this.groupBox7.Location = new System.Drawing.Point(18, 81);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(831, 668);
            this.groupBox7.TabIndex = 19;
            this.groupBox7.TabStop = false;
            // 
            // groupBox12
            // 
            this.groupBox12.BackColor = System.Drawing.Color.LightGray;
            this.groupBox12.Controls.Add(this.groupBox5);
            this.groupBox12.Controls.Add(this.textBox5);
            this.groupBox12.Location = new System.Drawing.Point(12, 552);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(800, 110);
            this.groupBox12.TabIndex = 4;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "문제 5번";
            // 
            // groupBox11
            // 
            this.groupBox11.BackColor = System.Drawing.Color.LightGray;
            this.groupBox11.Controls.Add(this.groupBox4);
            this.groupBox11.Controls.Add(this.textBox4);
            this.groupBox11.Location = new System.Drawing.Point(12, 420);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(800, 110);
            this.groupBox11.TabIndex = 3;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "문제 4번";
            // 
            // groupBox10
            // 
            this.groupBox10.BackColor = System.Drawing.Color.LightGray;
            this.groupBox10.Controls.Add(this.textBox3);
            this.groupBox10.Controls.Add(this.groupBox3);
            this.groupBox10.Location = new System.Drawing.Point(12, 293);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(800, 110);
            this.groupBox10.TabIndex = 2;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "문제 3번";
            // 
            // groupBox9
            // 
            this.groupBox9.BackColor = System.Drawing.Color.LightGray;
            this.groupBox9.Controls.Add(this.textBox2);
            this.groupBox9.Controls.Add(this.groupBox2);
            this.groupBox9.Location = new System.Drawing.Point(12, 163);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(800, 110);
            this.groupBox9.TabIndex = 1;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "문제 2번";
            // 
            // groupBox8
            // 
            this.groupBox8.BackColor = System.Drawing.Color.LightGray;
            this.groupBox8.Controls.Add(this.groupBox1);
            this.groupBox8.Controls.Add(this.textBox1);
            this.groupBox8.Location = new System.Drawing.Point(9, 32);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(800, 110);
            this.groupBox8.TabIndex = 0;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "문제 1번";
            // 
            // Form8
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1184, 761);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.groupBox7);
            this.Name = "Form8";
            this.Text = "시험";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox7.ResumeLayout(false);
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RadioButton first1_1;
        private System.Windows.Forms.RadioButton sec2_1;
        private System.Windows.Forms.RadioButton th3_1;
        private System.Windows.Forms.RadioButton four4_1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.RadioButton first1_2;
        private System.Windows.Forms.RadioButton sec2_2;
        private System.Windows.Forms.RadioButton th3_2;
        private System.Windows.Forms.RadioButton four4_2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.RadioButton first1_3;
        private System.Windows.Forms.RadioButton sec2_3;
        private System.Windows.Forms.RadioButton th3_3;
        private System.Windows.Forms.RadioButton four4_3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.RadioButton first1_5;
        private System.Windows.Forms.RadioButton sec2_5;
        private System.Windows.Forms.RadioButton th3_5;
        private System.Windows.Forms.RadioButton four4_5;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.RadioButton first1_4;
        private System.Windows.Forms.RadioButton sec2_4;
        private System.Windows.Forms.RadioButton th3_4;
        private System.Windows.Forms.RadioButton four4_4;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
    }
}