﻿namespace ttset
{
    partial class Form11
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea3 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend3 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea4 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend4 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series4 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.close = new System.Windows.Forms.Button();
            this.grade_sort = new System.Windows.Forms.Button();
            this.name_sort = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.pie_chart = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.next_quzi = new System.Windows.Forms.Button();
            this.quzi_num = new System.Windows.Forms.Label();
            this.rigth_rating = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pie_chart)).BeginInit();
            this.SuspendLayout();
            // 
            // close
            // 
            this.close.Location = new System.Drawing.Point(1027, 677);
            this.close.Name = "close";
            this.close.Size = new System.Drawing.Size(134, 62);
            this.close.TabIndex = 0;
            this.close.Text = "뒤로가기";
            this.close.UseVisualStyleBackColor = true;
            this.close.Click += new System.EventHandler(this.button3_Click);
            // 
            // grade_sort
            // 
            this.grade_sort.Location = new System.Drawing.Point(1027, 463);
            this.grade_sort.Name = "grade_sort";
            this.grade_sort.Size = new System.Drawing.Size(134, 62);
            this.grade_sort.TabIndex = 2;
            this.grade_sort.Text = "성적 정렬";
            this.grade_sort.UseVisualStyleBackColor = true;
            this.grade_sort.Click += new System.EventHandler(this.button4_Click);
            // 
            // name_sort
            // 
            this.name_sort.Location = new System.Drawing.Point(1027, 395);
            this.name_sort.Name = "name_sort";
            this.name_sort.Size = new System.Drawing.Size(134, 62);
            this.name_sort.TabIndex = 3;
            this.name_sort.Text = "이름 정렬";
            this.name_sort.UseVisualStyleBackColor = true;
            this.name_sort.Click += new System.EventHandler(this.button5_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 25;
            this.dataGridView1.Size = new System.Drawing.Size(793, 330);
            this.dataGridView1.TabIndex = 4;
            // 
            // chart1
            // 
            chartArea3.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea3);
            legend3.Name = "Legend1";
            this.chart1.Legends.Add(legend3);
            this.chart1.Location = new System.Drawing.Point(12, 348);
            this.chart1.Name = "chart1";
            series3.ChartArea = "ChartArea1";
            series3.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Bar;
            series3.Legend = "Legend1";
            series3.Name = "Grade";
            this.chart1.Series.Add(series3);
            this.chart1.Size = new System.Drawing.Size(1160, 401);
            this.chart1.TabIndex = 5;
            this.chart1.Text = "chart1";
            // 
            // pie_chart
            // 
            chartArea4.Name = "ChartArea1";
            this.pie_chart.ChartAreas.Add(chartArea4);
            legend4.Name = "Legend1";
            this.pie_chart.Legends.Add(legend4);
            this.pie_chart.Location = new System.Drawing.Point(811, 12);
            this.pie_chart.Name = "pie_chart";
            this.pie_chart.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Pastel;
            series4.ChartArea = "ChartArea1";
            series4.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Pie;
            series4.Legend = "Legend1";
            series4.Name = "rate";
            this.pie_chart.Series.Add(series4);
            this.pie_chart.Size = new System.Drawing.Size(361, 330);
            this.pie_chart.TabIndex = 6;
            this.pie_chart.Text = "chart2";
            // 
            // next_quzi
            // 
            this.next_quzi.Location = new System.Drawing.Point(1038, 280);
            this.next_quzi.Name = "next_quzi";
            this.next_quzi.Size = new System.Drawing.Size(134, 62);
            this.next_quzi.TabIndex = 7;
            this.next_quzi.Text = "다음문제";
            this.next_quzi.UseVisualStyleBackColor = true;
            this.next_quzi.Click += new System.EventHandler(this.next_quzi_Click);
            // 
            // quzi_num
            // 
            this.quzi_num.AutoSize = true;
            this.quzi_num.Location = new System.Drawing.Point(824, 315);
            this.quzi_num.Name = "quzi_num";
            this.quzi_num.Size = new System.Drawing.Size(39, 15);
            this.quzi_num.TabIndex = 8;
            this.quzi_num.Text = "label1";
            // 
            // rigth_rating
            // 
            this.rigth_rating.AutoSize = true;
            this.rigth_rating.Location = new System.Drawing.Point(824, 22);
            this.rigth_rating.Name = "rigth_rating";
            this.rigth_rating.Size = new System.Drawing.Size(39, 15);
            this.rigth_rating.TabIndex = 9;
            this.rigth_rating.Text = "label1";
            // 
            // Teacher_result
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(1184, 761);
            this.Controls.Add(this.rigth_rating);
            this.Controls.Add(this.quzi_num);
            this.Controls.Add(this.next_quzi);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.name_sort);
            this.Controls.Add(this.grade_sort);
            this.Controls.Add(this.close);
            this.Controls.Add(this.pie_chart);
            this.Controls.Add(this.chart1);
            this.Name = "Teacher_result";
            this.Text = "Form6";
            this.Load += new System.EventHandler(this.Form6_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pie_chart)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button close;
        private System.Windows.Forms.Button grade_sort;
        private System.Windows.Forms.Button name_sort;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
        private System.Windows.Forms.DataVisualization.Charting.Chart pie_chart;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button next_quzi;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label quzi_num;
        private System.Windows.Forms.Label rigth_rating;
    }
}